# ShinyItemAnalysis
Test and Item Analysis via Shiny.


Interactive shiny application for analysis of educational tests and their items including DIF detection.
